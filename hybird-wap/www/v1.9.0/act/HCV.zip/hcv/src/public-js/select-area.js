/**

 * 选择省市区

 * @author Jiangdw

 * @createDate 2015-09-23

 * @lastModify Jiangdw 2015-09-24

 * @param $

 */
;(function($, window, document, undefined){

    //顶级父ID, 第二级, 第三级, 第四级, 异步URL地址


    var topParentId_ = 100000, level_2 = 2, level_3 = 3, level_4 = 4, url_,

        _createProvinceSelector = function($obj, defaultValue){
            $.getJSON(url_, function(data){
                var options_ = defaultValue,
                    item;
                for(i in data){
                    item = data[i];
                    if(item.parentId == topParentId_ && item.level == level_2){
                        options_ += '<option value="'+item.areaId + '">'+item.cnName+'</option>';
                    }
                }
                $obj.html(options_);
            });
        },

        _createSelector = function($obj, parentId, level){
            $.getJSON(url_, function(data){
                var options_ = '<option value="">请选择</option>',
                    item;
                for(i in data){
                    item = data[i];
                    if(item.parentId == parentId && item.level == level){
                        if(level == level_2){
                            options_ += '<option value="'+item.areaId + '">'+item.cnName+'</option>';
                        } else {
                            options_ += '<option value="'+item.areaId+'" postcode="'+item.postcode+'" cityCode="'+item.cityCode+'" code="'+item.code+'">'+item.cnName+'</option>';
                        }
                    }
                }
                $obj.html(options_);
            });
        };

    $.fn.selectarea = function(options){
        var _$this = $(this), html = '',
            _$opts = $.extend({}, $.fn.selectarea.defaults, options);

        url_ = _$opts.url,

            _$dp = _$opts.province,
            _$dc = _$opts.city,
            _$da = _$opts.area,

            _pname = _$dp[0] === '' ? '请选择' : _$dp[0], _psname = _$dp[1], _pid = _$dp[2],
            _cname = _$dc[0] === '' ? '请选择' : _$dc[0], _csname = _$dc[1], _cid = _$dc[2], _cpostcode = _$dc[3], _ccitycode = _$dc[4],
            _aname = _$da[0] === '' ? '请选择' : _$da[0], _asname = _$da[1], _aid = _$da[2], _apostcode = _$da[3],

            _defaultProvinceOption = '<option value="'+_pid+'">'+_pname+'</option>';

        html += '<select name="'+_psname+'" required="required">'+_defaultProvinceOption+'</select> ';
        html += '<select name="'+_csname+'" required="required"><option value="'+_cid+'" postcode="'+_cpostcode+'" cityCode="'+_ccitycode+'">'+_cname+'</option></select> ';
        html += '<select name="'+_asname+'" required="required"><option value="'+_aid+'" postcode="'+_apostcode+'">'+_aname+'</option></select>';

        _$this.html(html);

        var _$p = _$this.find('select[name='+_psname+']'),
            _$c = _$this.find('select[name='+_csname+']'),
            _$a = _$this.find('select[name='+_asname+']');

        _createProvinceSelector(_$p, _defaultProvinceOption);

        _$p.on('change', function(){
            _createSelector(_$c, $(this).val(), level_3);
            _$a.html('<option value="">请选择</option>');
        });

        _$c.on('change', function(){
            _createSelector(_$a, $(this).val(), level_4);
        });

        _$a.on('change', function(){
            if($.isFunction(_$opts.onChanged)) {
                _$opts.onChanged(_$p, _$c, _$a);
            }
        });

        return this;
    };

    $.fn.selectarea.defaults = {
        province: ['', 'province', ''],//[省, 省表单名称, 省ID]

        city: ['', 'city', '', '', ''],//[城市,城市表单名称,城市ID,邮政编码,区号]

        area: ['', 'area', '', ''],//[区,区表单名称,区ID,区邮政编码]

        url: '/js/plugin/selectarea/area-json.js',
        onChanged: null
    };

    /**

     * $.fn.selectarea.defaults = {

		province: ['江苏省', 'province', '320000'],

		city: ['无锡市', 'city', '320200', '214000', '0510'],

		area: ['滨湖区', 'area', '320211', '214123'],

		url: '/js/plugin/selectarea/area-json.js',

		onChanged: null

	};

     */


})(jQuery, window, document);


