/**
 * Created by lvtianyu on 16/8/10.
 */
var controller = (function ($, window, document) {
    var item = 1,
        $join=$("#join"),
        doctorNumber,
        patientNumber,
        $a = $("#a");
// 初始化数据
    function initParam() {
        var data = {
                sign: "d762d69837fc3d9f8055eb20d85acc35"
            },
            url = "queryHcvDocPatientCount.htm",
            public = new PublickFn(url, data, analyticQueryAjax);
        public.ajaxFn();
        public = null;
    }

    function analyticQueryAjax(data) {
        doctorNumber=data[0].countTotal;
        patientNumber=data[1].countTotal;
        $("#patient-number").html(patientNumber);
        $("#doctor-number").html(doctorNumber);
    }

    function carouselFn() {
        var oneTime = setTimeout(function () {
            prevFn();
            item++;
            if (item > 3) {
                item = 1;
            }
            clearTimeout(oneTime)
        }, 1200);

        var oneTime2 = setTimeout(function () {
            nextFn();
            clearTimeout(oneTime2)

        }, 1600)

    }

    function prevFn() {
        var i = "#a" + item;
        $(i).addClass("right");
    }

    function nextFn() {
        var i = "#a" + item,
            j = "#" + item;
        $(".active").removeClass("active right");
        $(i).addClass("active");
        $(j).addClass("active");
    }

    var intervalTime = setInterval(function () {
        return carouselFn();

    }, 6000);

    $a.on("click", function (e) {
        var id = e.target.id;
        console.log(id);
        clearInterval(intervalTime);
        item = id;
        nextFn()
    });

    $join.on("click",function () {
        intervalTime=null;
        locationSelf.href="Show-love.html"
    });

    var doInit = function () {
        initParam();//初始化页面变量
    };

    return {
        doInit: doInit
    }
})(Zepto, window, document);

$(function () {
    controller.doInit();
});