
var controller = (function ($, window, document) {
    var item=1,
        userNamePatient,
        $heart=$("#heart"),
        nickName,
        $a=$("#a");
    function initParam() {
        userNamePatient=oGetVars.userName || userName;//如果没有患者用户就是本人登录
        //永久保存在页面的信息
        console.log(oGetVars)
    }

    function initDataAjax() {
        var data = {
                sign: "d762d69837fc3d9f8055eb20d85acc35"
            },
            url = "queryHcvDocPatientCount.htm",
            public = new PublickFn(url, data, analyticQueryAjax);
        public.ajaxFn();
        public = null;
    }

    function analyticQueryAjax(data) {
        var doctorNumber=data[0].countTotal,
            patientNumber=data[1].countTotal;
        $("#patient-number").html(patientNumber);
        $("#doctor-number").html(doctorNumber);

    }


    $heart.on("click",getHeart);

    function getHeart() {
        console.log(userNamePatient);
        if (userNamePatient){
            getHeartAjax()
        }else{
            var _notice="不能给自己点赞,分享活动让他人为你点赞";
            return noticeSetTimeoutPublick(_notice);
        }
    }

    function getHeartAjax() {
        var data = {
                toHelperName: userNamePatient,
                openId: openId,
                sign:'9cd0445e2ee4cceadd4f02a17edb8e57'
            },
            url = "addLoveCount.htm",
            public = new PublickFn(url, data, analyticAddLoveAjax);
        public.ajaxFn();
        public = null;

    }

    function analyticAddLoveAjax(data) {
        var result='成功点赞，送给ta一个爱心',
            show=1;
        if(data){
            result=data
            show=2;
        }
        locationSelf.href = newPage+'result='+result+"&show="+show;
    }

    function carouselFn() {
        var oneTime=setTimeout(function () {
            prevFn();
            item++;
            if(item>3){
                item=1;
            }
            clearTimeout(oneTime)
        },1200);

        var oneTime2=setTimeout(function () {
            nextFn();
            clearTimeout(oneTime2)

        },1600)

    }
    function prevFn() {
        var i="#a"+item;
        $(i).addClass("right");
    }

    function nextFn() {
        var i="#a"+item,
            j="#"+item;
        $(".active").removeClass("active right");
        $(i).addClass("active");
        $(j).addClass("active");
    }

    var intervalTime= setInterval(function () {
        return carouselFn();

    },6000);

    $a.on("click",function (e) {
        var id=e.target.id;
        console.log(id);
        clearInterval(intervalTime);
        item=id;
        nextFn()
    });

    var doInit = function () {
        initParam();//初始化页面变量
        initDataAjax();
    };

    return {
        doInit: doInit
    }
})(Zepto, window, document);

$(function () {
    controller.doInit();
});/**
 * Created by lvtianyu on 16/8/10.
 */
