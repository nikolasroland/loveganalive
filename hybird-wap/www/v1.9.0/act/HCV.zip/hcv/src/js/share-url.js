/**
 * Created by lvtianyu on 16/6/29.
 */
var urlContent = {};
function url() {
    var id = localStorage.getItem("type");
    console.log("userName", id);
    if (id) {
        if (id == 1) {
            urlContent = {
                h: htmlUrl + "/pages/doctor-page.html?userName=" + userName,
                title: "丙肝活动",
                content: "我正参加“保驾护航抗丙肝”公益活动，快来帮我攒爱心，您更有机会获得iPhone7手机！",
                pic: htmlUrl + "/source/img/share-img.png"

            }
        } else {
            urlContent = {
                h: htmlUrl + "/pages/challenge-detail.html?userName=" + userName,
                title: "丙肝活动",
                content: "为“保驾护航抗丙肝”公益活动点赞赢iPhone7，您的帮助将挽救一个丙肝患者的生命！",
                pic: htmlUrl + "/source/img/share-img.png"
            };
        }


    } else {
        urlContent = {
            h: htmlUrl + "/pages/grab-red.html?userName=" + userName,
            title: "丙肝活动",
            content: "世界肝炎日刚刚过去，快来为肝炎公益点赞，有机会赢取iPhone7",
            pic: htmlUrl + "/source/img/share-img.png"
        };
    }
}

function isWX() {
    // var ua = navigator.userAgent.toLowerCase();
    // if(ua.match(/MicroMessenger/i)=="micromessenger") {
    // 	return true;
    // } else {
    // 	return false;
    // }
}

function initWxJSSDK() {
    var thisPageUrl = location.href;
    alert(thisPageUrl);
    $.ajax({
        type: "post",
        url: nodeurl + 'getJsApiTicketShare.htm',
        data: {
            sign: 'c48d421b4364182263376e7b9d905067',
            url: thisPageUrl
        },
        dataType: dataType,
        beforeSend: function (XMLHttpRequest) {
        },
        success: function (json) {
            if (json.result == "ok") {
                //var signJson = eval("(" + json.values + ")");
                console.log(json)
                var signJson = json,
                    appid = signJson.appid,
                    timestamp = signJson.timestamp,
                    noncestr = signJson.noncestr,
                    signature = signJson.sign,
                    url = signJson.url;

                // console.log(appid,timestamp,noncestr,signature);

                if (wx != undefined) {
                    //初始化微信sdk
                    wx.config({
                        debug: true,
                        appId: appid,
                        timestamp: timestamp,
                        nonceStr: noncestr,
                        signature: signature,
                        jsApiList: [
                            'onMenuShareTimeline',
                            'onMenuShareAppMessage',
                            'chooseWXPay',
                            'checkJsApi',
                            'chooseImage',
                            'previewImage',
                            'uploadImage',
                            'downloadImage'
                        ]
                    });
                }


            } else {
                alert(json.errormsg);
            }
        },
        error: function () {
            //请求出错处理
            //console.log("error");
        },
        complete: function (XMLHttpRequest, textStatus) {
            //HideLoading();//关闭进度条
            //alert("complete");
            //console.log("complete");
        }
    });

}

if (wx != undefined) {
    wx.ready(function () {
        //判断当前客户端版本是否支持指定JS接口
        wx.checkJsApi({
            jsApiList: [
                'onMenuShareTimeline',
                'onMenuShareAppMessage',
                'chooseWXPay',
                'checkJsApi',
                'chooseImage',
                'previewImage',
                'uploadImage',
                'downloadImage'
            ],
            success: function (res) {
                // console.log(res);
                console.log(urlContent);
            }
        });

        //朋友圈
        wx.onMenuShareTimeline({
            title: urlContent.title, // 分享标题
            link: urlContent.h, // 分享链接
            imgUrl: urlContent.pic, // 分享图标
            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
            trigger: function (res) {
                //shareLog()
                //alert('用户点击分享到朋友圈');
            },
            success: function (res) {

                //shareLog()
                alert('已分享');
            },
            cancel: function (res) {
                //alert('已取消');
            },
            fail: function (res) {
                alert(JSON.stringify(res));
            }
        });

        //分享给朋友
        wx.onMenuShareAppMessage({
            title: urlContent.title, // 分享标题
            desc: urlContent.content, // 分享描述
            link: urlContent.h, // 分享链接
            imgUrl: urlContent.pic, // 分享图标
            type: 'link', // 分享类型,music、video或link，不填默认为link
            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
            success: function () {
                //alert("成功")
                // 用户确认分享后执行的回调函数
                //shareLog()
                alert('已分享');
            },
            cancel: function () {
                // 用户取消分享后执行的回调函数
                //alert('已取消');
            },
            fail: function (res) {
                alert(JSON.stringify(res));
            }
        });

    });
}

$(function () {
    url();
    initWxJSSDK()
});

