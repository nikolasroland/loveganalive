/**
 * Created by lvtianyu on 16/7/5.
 */
var documentSelf = document;
documentSelf.writeln("<meta http-equiv='X-UA-Compatible' content='IE=edge'>");
documentSelf.writeln("<meta name=\"screen-orientation\" content=\"portrait\">");
documentSelf.writeln("<meta name=\"x5-orientation\" content=\"portrait\">");
documentSelf.writeln("<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>");
documentSelf.writeln('<link rel="stylesheet" href="../source/css/publick.css">');
documentSelf.writeln("<script src='../source/public-js/zepto.min.js'></script>");
// documentSelf.writeln("<script src='../source/public-js/jQuery-2.1.4.min.js'></script>");
documentSelf.writeln("<script src='../source/public-js/locache.min.js'></script>");
// documentSelf.writeln("<script src='../source/js/wx.js'></script>");
documentSelf.writeln("<script src='../source/js/wx.js'></script>");
documentSelf.writeln("<script src='http://res.wx.qq.com/open/js/jweixin-1.0.0.js'></script>");
