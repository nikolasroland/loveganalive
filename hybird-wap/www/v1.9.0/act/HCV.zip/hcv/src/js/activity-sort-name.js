/**
 * Created by lvtianyu on 16/8/9.
 */
var controller = (function ($, window, document) {
    var $province = $("#province"),
        $listShopShow = $("#list-shop-show"),
        city='',
        state='',
        page=1,
        rows=20,
        total,
        $windowHeight = $(window).height(),
        $Container,
        userNameDoctor,
        $moreBtn = $("#more"),
        $city = $("#city");


// 初始化数据
    function initParam() {
        var tpl = "";
        for (var i in cities) {
            tpl += '<option value="' + i + '">' + i + '</option>'
        }
        $province.html(tpl);

        initDataAjax()
    }

    function initDataAjax() {
        console.log(state,city);

        var data = {
                sign: '5f203885575bf2c252b8f3f6b6aa6925',
                page: page,
                state: state,
                city: city,
                rows: rows
            },
            url = "queryDocLoveCountRank.htm",
            public = new PublickFn(url, data, analyticListAjax);
        public.ajaxFn();
        public = null;

    }

    function analyticListAjax(data) {
        total=data.total;
        var tpls = "",
            data = data.rows.reverse(),
            image,
            time,
            number,
            hospital,
            name,
            state,
            departments,
            data_i,
            i = data.length - 1;

        if (i > -1) {
            do {
                data_i = data[i];
                image = data_i.headimgurl || "../source/img/img-defaule-head.png";
                name = data_i.nickName || "无";
                hospital = data_i.hospital || "无";
                number = data_i.loveCount || 0;
                departments = data_i.departments || "无";
                state=data_i.state || "无";

                tpls += '<li><div><img src='+image+' >'+
                    '</div><ul class="list-li-border-bottom"><li><div class="list-name"><span>'+
                    name+'</span>'+state+'</div><div class="ctivity-content">'+
                    '<span>'+hospital+'</span>'+departments+'</div></li><li><div class="list-show-heart">'+
                    '<img src="../src/img/doctor-page-heart.png"> X<span>'+number+'</span>颗</div></li></ul></li>'

            } while (--i >= 0);

        } else {
            tpls = '<li class="notice-none">暂无内容!</li>';
        }

        $listShopShow.append(tpls);
        $Container = $(".main-content").height();
        $moreBtn.hide();
    }


    $(window).bind("scroll", function () {
        //绑定scroll事件;
        var height = this.pageYOffset + $windowHeight;
        console.log(height >= $listShopShow.height() , total >= page * rows, $listShopShow.height(), height)

        if (height >= $listShopShow.height() && total >= page * rows) {
            $moreBtn.show();
            console.log('come');
            page++;
            initDataAjax()
        }
    });


    $province.on("change", function () {

        var val = $province.val();
        state = val;
        console.log("state"+val)
        return cityFn(val);

    });

    function cityFn(val) {

        var tpl = "",
            data = cities[val].reverse(),
            len = data.length,
            city,
            i = len - 1;
        do {
            city = data[i];
            tpl += '<option value="' + city + '">' + city + '</option>'
        } while (--i >= 0);

        $city.html(tpl);
        city=data[len - 1];

        if(state){
            page=1;
            $listShopShow.html('');
            if(state=="请先选择您所在的省份"){
                state='';
                city='';
            }
            initDataAjax()
        }
    }

    $city.on("change", function () {
        var val = $city.val(),
            text;
        city = val;
        if(city){
            page=1;
            $listShopShow.html('');
            initDataAjax()
        }
        console.log(val);
    });


    var doInit = function () {
        initParam();//初始化页面变量
    };

    return {
        doInit: doInit
    }
})(Zepto, window, document);

$(function () {
    controller.doInit();
});