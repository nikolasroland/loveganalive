/**
 * Created by lvtianyu on 16/8/10.
 */
var controller = (function ($, window, document) {
    var $province = $("#province"),
        $changeCity = $("#change-city"),
        $nextBtnAddress = $("#next-btn-address"),
        isInput = false,//当填写地址时用到
        data = {},
        $city = $("#city");


// 初始化数据
    function initParam() {
        var data1 = locache.session.get("data");
        data = JSON.parse(data1);
        var tpl = "";
        for (var i in cities) {
            tpl += '<option value="' + i + '">' + i + '</option>'
        }
        $province.html(tpl);

    }

    $province.on("change", function () {
        var val = $province.val();
        console.log(val);
        data.state = val;
        return cityFn(val);
    });

    function cityFn(val) {
        var tpl = "",
            data = cities[val].reverse(),
            len = data.length,
            city,
            i = len - 1;
        do {
            city = data[i];
            tpl += '<option value="' + city + '">' + city + '</option>'
        } while (--i >= 0);

        $city.html(tpl);

        data.city = data[len - 1];
    }

    $city.on("change", function () {
        var val = $city.val(),
            text;
        data.city = val;
        if (val == '其它') {
            text = '<input type="text" placeholder="请录入您的所在的市/区" id="input-city">';
            $changeCity.html(text);
            isInput = true;

        } else {
            return
        }
        console.log(val);
    });

//        function bindCityInput(inputCity) {
//            $(inputCity).on("click",function () {
//
//            })
//        }

    $nextBtnAddress.on("click", sendAjax);

    function sendAjax() {
        if (!isInput) {

            hrefPage()

        } else {
            var $inputCity = $("#input-city"),
                val = $inputCity.val(),
                _notive = "请您填写正确的市区!",
                num = 10,
                RE = /[\u4E00-\u9FA5]/g;
            data.city = testInput(val, RE, _notive, num, $inputCity);
            if (data.city) {
                hrefPage()
            } else {
                return;
            }
        }
    }

    function hrefPage() {
        var data3;
        data3 = JSON.stringify(data);
        locache.session.set("data", data3);

        locationSelf.href = "message-sex.html"
    }


    var doInit = function () {
        initParam();//初始化页面变量
    };

    return {
        doInit: doInit
    }
})(Zepto, window, document);

$(function () {
    controller.doInit();
});