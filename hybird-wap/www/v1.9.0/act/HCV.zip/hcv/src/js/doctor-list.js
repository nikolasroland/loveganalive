/**
 * Created by lvtianyu on 16/8/9.
 */
var controller = (function ($, window, document) {
    var $listShopShow = $("#list-shop-show"),
        userNameDoctor,
        rows = 12,
        page = 1,
        total,
        $windowHeight = $(window).height(),
        $Container,
        $moreBtn = $("#more");


// 初始化数据
    function initParam() {
        console.log($Container);
        userNameDoctor = oGetVars.userNameDoctor || userName;//如果userNameDoctor不存在我就用username,也说明不是分享
       console.log(userNameDoctor);
        initDataAjax()
    }

    function initDataAjax() {
        var data = {
                userName: userNameDoctor,
                sign: 'c9d77b16f8b81a542e36b8290456c031',
                page: page,
                rows: rows
            },
            url = "getLoveCountDetailInfo.htm",
            public = new PublickFn(url, data, analyticListAjax);
        public.ajaxFn();
        public = null;

    }


    function analyticListAjax(data) {
        total = data.total;
        var tpls = "",
            data = data.rows.reverse(),
            image,
            time,
            number,
            hospital,
            name,
            data_i,
            i = data.length - 1;

        if (i > -1) {
            do {
                data_i = data[i];
                image = data_i.headimgurl || "../source/img/img-defaule-head.png";
                name = data_i.nickName;
                hospital = data_i.hospital || "无";
                number = data_i.loveCount;
                time = data_i.minuteBefore;
                tpls += '<li><div><img   src=' + image + ' alt=""></div>' +
                    '<ul class="list-li-border-bottom"><li><div class="list-name">' +
                    '<span>' + name + '</span>' + hospital + '</div>' +
                    '<div class="list-show-heart"><img src="../src/img/doctor-page-heart.png" alt=""></div>' +
                    '</li><li><div class="ctivity-content">' + time +
                    '</div><div class="is-heart-num">' +
                    '+<span>' + number + '</span>颗</div></li></ul></li>';

            } while (--i >= 0);

        } else {
            tpls = '<li class="notice-none">暂无内容!</li>';
        }

        $listShopShow.append(tpls);
        $Container = $(".main-content").height();
        $moreBtn.hide();
    }


    $(window).bind("scroll", function () {
        //绑定scroll事件;
        var height = this.pageYOffset + $windowHeight;
        console.log(this.pageYOffset, $windowHeight, $listShopShow.height(), height)

        if (height >= $listShopShow.height() && total >= page * rows) {
            $moreBtn.show();
            console.log('come')
            page++;
            initDataAjax()
        }
    });

//        $.fn.lazyload = function (options) {
//            var elements = this;
//            var $container;
//            var settings = {
//                threshold: 0,
//                failure_limit: 0,
//                event: 'scroll',
//                effect: 'show',
//                container: window,
//                data_attribute: "original",
//                skip_invisible: false,
//                appear: null,
//                load: null//载入远程 HTML 文件代码并插入至 DOM 中。
//            };
//
//            function update() {
//                elements.each(function () {
//                    var $this = $(this);
//                    if (settings.skip_invisible && !$this.is(":visible")) {
//                        return;
//                    }
//                    console.log("false", $.belowthefold(this, settings));
//                    if (!$.belowthefold(this, settings)) {
//                        $this.trigger("appear");
//                        /* if we found an image we'll load, reset the counter */
//                    } else {
//                        return false;
//                    }
//                });
//            }
//
//            if (options) {
//                if (undefined !== options.failurelimit) {
//                    options.failure_limit = options.failurelimit;
//                    delete options.failurelimit;
//                }
//                if (undefined !== options.effectspeed) {
//                    options.effect_speed = options.effectspeed;
//                    delete options.effectspeed;
//                }
//                $.extend(settings, options)
//            }
//            $container = (settings.container === undefined || settings.container === window) ? $window : $(settings.container);
//            $container.bind(settings.event, function () {//绑定scroll事件;
//                return update();
//            });
//
//            //像页面上加载src属性直的方法
//            this.each(function () {
//                var self = this;
//                var $self = $(self);
//                //当出现时触发加载原始图像  为每一个匹配元素的特定事件（像click）绑定一个一次性的事件处理函数。
//                $self.one("appear", function () {
//                    $self.bind("load", function () {
//                        var original = $self.attr("data-" + settings.data_attribute);
//                        $self.removeClass("lazy");
//                        if ($self.is('img')) {
//                            $self.attr("src", original);
//                        } else {
//                            $self.css("background-image", "url('" + original + "')");
//                        }
//                    }).attr("src", $self.attr("data-" + settings.data_attribute));
//                });
//            });
//            if ((/(?:iphone|ipod|ipad).*os 5/gi).test(navigator.appVersion)) {
//                $window.bind("pageshow", function (event) {
//                    if (event.originalEvent && event.originalEvent.persisted) {
//                        elements.each(function () {
//                            $(this).trigger("appear");
//                            console.log("jjj");
//                        })
//                    }
//                })
//            }
//            //强制初始检查，如果图像出现
//            update();
//            return this
//        };
//
//        $.belowthefold = function (element, settings) {
//            var fold = (window.innerHeight ? window.innerHeight : $window.height()) + $window.scrollTop();
//            console.log("a",fold, $Container, $(element).offset().top);
//            if (fold < $Container) {
//                return fold <= $(element).offset().top - settings.threshold;
//            } else if (fold == $Container) {
////                initDataAjax();
//                return true;
//            }
//        };

//        $.extend($.expr[":"], {
//            "below-the-fold": function (a) {
//                return $.belowthefold(a, {threshold: 0});
//            }
//        });
//

    var doInit = function () {
        initParam();//初始化页面变量
    };

    return {
        doInit: doInit
    }
})(Zepto, window, document);

$(function () {
    controller.doInit();
});