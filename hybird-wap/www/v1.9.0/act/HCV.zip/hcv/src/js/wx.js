var
    dataType = "json",   //正式

    nodejsServerIp = "http://testmanage.aiganyisheng.net",//正式

    contextPath = "/product/app/",

    nodeurl = nodejsServerIp + contextPath,
//公共代码
    htmlUrl='http://testwap.aiganyisheng.net/v1.9.0/act/hcv',

    locationSelf = location,

    locationSelfSearch = locationSelf.search,

    viewWidth = localStorage.getItem("viewWidth"),

    html = document.documentElement,

    oGetVars={},
    openId=localStorage.getItem("openId"),

    userName = localStorage.getItem("userName");

if (!viewWidth) {
    // document.addEventListener('DOMContentLoaded', function () {
    if (html) {
        var windowWidth = html.clientWidth / 7.5;
        viewWidth = windowWidth + 'px';
        localStorage.setItem("viewWidth", viewWidth);
        html.style.fontSize = viewWidth;
    }

} else {
    html.style.fontSize = viewWidth;
}

var ua = navigator.userAgent.toLowerCase();


if (ua.match(/MicroMessenger/i) == "micromessenger") {


} else {

}

function checkWxLogin(userType) {
    userName =localStorage.getItem("userName");
    console.log(userName)
    if (!userName || undefined == userName || null == userName || "" == userName) {
        locationSelf.href = nodejsServerIp + "/trade/app/redirectWechatLogin.htm?sign=5540b83596ed1584f7a0cf2faa4bfab6&userType="+userType;
    }

}

(function (sSearch) {
    var rNull = /^\s*$/, rBool = /^(true|false)$/i;

    function buildValue(sValue) {
        if (rNull.test(sValue)) {
            return null;
        }
        if (rBool.test(sValue)) {
            return sValue.toLowerCase() === "true";
        }
        if (isFinite(sValue)) {
            return parseFloat(sValue);
        }
        if (isFinite(Date.parse(sValue))) {
            return new Date(sValue);
        }
        return sValue;
    }

    if (sSearch.length > 1) {
        for (var aItKey, nKeyId = 0, aCouples = sSearch.substr(1).split("&"); nKeyId < aCouples.length; nKeyId++) {
            aItKey = aCouples[nKeyId].split("=");
            oGetVars[decodeURIComponent(aItKey[0])] = aItKey.length > 1 ? buildValue(decodeURIComponent(aItKey[1])) : null;
            //此处将unescape()替换了
        }
    }
})(locationSelfSearch);


