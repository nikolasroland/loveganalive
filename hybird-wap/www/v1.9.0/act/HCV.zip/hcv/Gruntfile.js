/**
 * Created by lvtianyu on 16/8/4.
 */
module.exports = function (grunt) {
    grunt.initConfig({
        pkg:grunt.file.readJSON('package.json'),
        concat:{
            options:{
                separator:';'
            },
            dist:{
                src:['src/**/*.js'],
                dest:'source/<%= pkg.name %>.js'
            }
        },
        jshint: {
            files: ['Gruntfile.js', 'src/**/*.js', 'test/**/*.js'],
            options: {
                globals: {
                    jQuery: true,
                    console: true,
                    module: true
                }
            }
        },
        uglify: {
            options: {
                mangle:true,
                compress:{
                    drop_console:true
                },
                report:'min',//输出压缩率,可选对值有false(不输出值)
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n'

            },
            my_target: {
                files: [{
                    expand: true,
                    cwd: 'src',
                    src: '**/*.js',
                    dest: 'source'
                }]
            }
        },
        watch: {
            files: ['src/**/*.js'],
            tasks: ['concat','uglify']

        }

    });
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.registerTask('default', ['watch', 'concat', 'uglify']);
};